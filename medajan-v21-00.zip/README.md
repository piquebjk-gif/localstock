# localstock
oflıne stock
